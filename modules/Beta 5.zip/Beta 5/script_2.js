$( document ).ready(function() {
	$('#t1').hide();	
	$('#t2').hide();	
	$('#t3').hide();	
	$('#t4').hide();	
	$('#t5').hide();

	$('#d1').hide();
	$('#d2').hide();
	$('#d3').hide();
	$('#d4').hide();
	$('#d5').hide();
	
	var cuenta = 0; //cuenta los ciclos (lo deshabilite)
	
	//Asignacion de direccion IP para cada Dispositivo.
	var ip_1 = "192.168.1.101"; //10.0.0.5
	var ip_2 = "192.168.1.102";
	var ip_3 = "192.168.1.103";
	var ip_4 = "192.168.1.104";
	var ip_5 = "192.168.1.105";
	
	var fun_1, device, chambaInicial_1;
	var fun_2, device_2, chambaInicial_2;
	var fun_3, device_3, chambaInicial_3;
	var fun_4, device_4, chambaInicial_4;
	var fun_5, device_5, chambaInicial_5;
	
	var cont = 1;
	//var valTermis;
	
	var graf_D1= [];
	// Charts and gauges objects
	var tempChar, tempChar_2, humChar;
	var tempGauge, humGauge;

	// Arrays that store datapoints for the two charts
	var tempData = new Array();
	var tempData_2 = new Array();
	var humData = new Array();
	
	// Create "dummy" data in the past for the two charts
    var startTime = (new Date()).getTime() - 200;
	//var cc = 1;
	for(var i = 0; i < 1; i++) {	
		tempData.push([startTime, 1]);
		tempData_2.push([startTime, 1]);
		startTime += 10000;
		//cc += 10000;
	} 
	
	
	/*for(var i = 0; i < 1; i++) {			
		graf_D1.push([startTime, 20]);
		graf_D1.push([startTime, 20]);
		startTime += 10000;
	} */
	
	showCharts();
	
	 chambaInicial_1 = function (){
		if(ip_1 != false ){
		  //  device = new Device(ip_1); // Dispositivo 1 
		    $('#d1').show(200);
			//fun_1();
			trae_info();
		}
		//else{ $('#d1').hide(200);}
			if(++cont > 0){
			setTimeout(chambaInicial_1,5000);
			}
	}
	setTimeout(chambaInicial_1, 5000);
	
	 chambaInicial_2 = function (){
		if (ip_2 != false){
		    //device_2 = new Device(ip_2); // Dispositivo 2
		    $('#d2').show(200);
			// fun_2();
			trae_info_2();
		}
		//else{ $('#d2').hide(200);}
		if(++cont > 0){
			setTimeout(chambaInicial_2,5000);
			}
	 }
	setTimeout(chambaInicial_2, 5000);
	
	chambaInicial_3 = function (){
		if(ip_3 != false){
		    //device_3 = new Device(ip_3); // Dispositivo 3 
		    $('#d3').show(200);
			//fun_3();
			trae_info_3();
		}
		//else{ $('#d3').hide(200);}
		if(++cont > 0){
			setTimeout(chambaInicial_3,5000);
			}
	}
	setInterval(chambaInicial_3, 5000);
	
	chambaInicial_4 = function (){
		if (ip_4 != false){
		   // device_4 = new Device(ip_4); // Dispositivo 4
		    $('#d4').show(200);
			//fun_4();
			trae_info_4();
		}
		//else{ $('#d4').hide(200);}
		if(++cont > 0){
			setTimeout(chambaInicial_4,5000);
			}
	}
	setInterval(chambaInicial_4, 5000);
	
	chambaInicial_5 = function (){
		if(ip_5 != false){
		    //device_5 = new Device(ip_5); // Dispositivo 5
		    $('#d5').show(200);
			//fun_5();
			trae_info_5();
		}
		//else{ $('#d5').hide(200);}
		if(++cont > 0){
			setTimeout(chambaInicial_5,5000);
			}
	}
	setInterval(chambaInicial_5, 5000);
	
	
	
	//Estado de los dispositivos (en linea o fuera de linea)
	var estado, estado_2, estado_3, estado_4, estado_5;
	
	/**
	// Dispositivo 1
	//var trabajoSucio = function() {
	fun_1 = function leeSensor_1(){	
    device.getVariable('connected', function(data) {
  
	estado = data;
   
    if ( estado != false){
		$('#status').html("en linea");
		$('#status').css("color","green");
		
		if ($('#t1').show() != true) {
			$('#t1').show(500);	
		}
		
		// Recibe Thermistorcito
	    device.getVariable('envia_Thermistor', function(data) {
			var valTermis = parseFloat(data.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor').html("desconectado");
				$('#valThermistor').css("color","red");
			}
			else{
				valTermis = valTermis.toFixed(2);
				$('#valThermistor').html(valTermis);
				$('#valThermistor').css("color","gray");
			}
		});
	
		// Recibe BMP180 temperatura
		device.getVariable('bmpTemp', function(data) {
			var redBMPT = data.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP').html(redBMPT);
		});
	
		// Recibe BMP180 presion
		device.getVariable('bmpPres', function(data) {
			$('#valPresBMP').html(data.bmpPres);
		});
    }
    else{
		$('#status').html("fuera de linea");
		$('#status').css("color","red"); 
	
		if ($('#t1').hide() != true) {
			$('#t1').hide(500);	
		}
		//$.ajaxq.clear(qname);
		return;
    }
		
 
    });
	}
	//setInterval(trabajoSucio, 5000);
	
	
	// Dispositivo 2
	//var trabajoSucio_2 = function() {
	fun_2 = function leeSensor_2(){	
		
    device_2.getVariable('connected', function(data) {
  
		estado_2 = data;
   
    if ( estado_2 != false){
		$('#status_2').html("en linea");
		$('#status_2').css("color","green"); 
	
		if ($('#t2').show() != true	){
			$('#t2').show(500);
		}
		
		// Recibe Thermistorcito
	    device_2.getVariable('envia_Thermistor', function(data) {
			var valTermis = parseFloat(data.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor_2').html("desconectado");
				$('#valThermistor_2').css("color","red"); 
			}
			else{
				valTermis = valTermis.toFixed(2);
				$('#valThermistor_2').html(valTermis);
				$('#valThermistor_2').css("color","gray");
			}
		});
	
		// Recibe BMP180 temperatura
		device_2.getVariable('bmpTemp', function(data) {
			var redBMPT = data.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_2').html(redBMPT);
		});
	
		// Recibe BMP180 presion
		device_2.getVariable('bmpPres', function(data) {
			$('#valPresBMP_2').html(data.bmpPres);
		});
    }
    else{
		$('#status_2').html("fuera de linea");
		$('#status_2').css("color","red"); 
		
		if ($('#t2').hide() != true	){
			$('#t2').hide(500);
		}
		//$.ajaxq.clear(qname);
		return;
    }
		
 
    });
	}
	//setInterval(trabajoSucio_2, 5000);

	// Dispositivo 3
	//var trabajoSucio_3 = function() {
	fun_3 = function leeSensor_3(){	
		
    device_3.getVariable('connected', function(data) {
  
		estado_3 = data;
   
    if ( estado_3 != false){
		$('#status_3').html("en linea");
		$('#status_3').css("color","green"); 
	
		if ($('#t3').show() != true	){
			$('#t3').show(500);
		}
		
		// Recibe Thermistorcito
	    device_3.getVariable('envia_Thermistor', function(data) {
			var valTermis = parseFloat(data.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor_3').html("desconectado");
				$('#valThermistor_3').css("color","red"); 
			}
			else{
				valTermis = valTermis.toFixed(2);
				$('#valThermistor_3').html(valTermis);
				$('#valThermistor_3').css("color","gray");
			}
		});
	
		// Recibe BMP180 temperatura
		device_3.getVariable('bmpTemp', function(data) {
			var redBMPT = data.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_3').html(redBMPT);
		});
	
		// Recibe BMP180 presion
		device_2.getVariable('bmpPres', function(data) {
			$('#valPresBMP_3').html(data.bmpPres);
		});
    }
    else{
		$('#status_3').html("fuera de linea");
		$('#status_3').css("color","red"); 
		
		if ($('#t3').hide() != true	){
			$('#t3').hide(500);
		}
		//$.ajaxq.clear(qname);
		return;
    }
		
 
    });
	}
	//setInterval(trabajoSucio_3, 5000);
	
	
	// Dispositivo 4
	//var trabajoSucio_4 = function() {
	fun_4 = function leeSensor_4(){	
		
    device_4.getVariable('connected', function(data) {
  
		estado_4 = data;
   
    if ( estado_4 != false){
		$('#status_4').html("en linea");
		$('#status_4').css("color","green"); 
	
		if ($('#t4').show() != true	){
			$('#t4').show(500);
		}
		
		// Recibe Thermistorcito
	    device_4.getVariable('envia_Thermistor', function(data) {
			var valTermis = parseFloat(data.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor_4').html("desconectado");
				$('#valThermistor_4').css("color","red"); 
			}
			else{
				valTermis = valTermis.toFixed(2);
				$('#valThermistor_4').html(valTermis);
				$('#valThermistor_4').css("color","gray");
			}
		});
	
		// Recibe BMP180 temperatura
		device_4.getVariable('bmpTemp', function(data) {
			var redBMPT = data.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_4').html(redBMPT);
		});
	
		// Recibe BMP180 presion
		device_2.getVariable('bmpPres', function(data) {
			$('#valPresBMP_4').html(data.bmpPres);
		});
    }
    else{
		$('#status_4').html("fuera de linea");
		$('#status_4').css("color","red"); 
		
		if ($('#t4').hide() != true	){
			$('#t4').hide(500);
		}
		//$.ajaxq.clear(qname);
		return;
    }
		
 
    });
	}
	//setInterval(trabajoSucio_4, 5000);
	
	// Dispositivo 5
	//var trabajoSucio_5 = function() {
	fun_5 = function leeSensor_5(){	
		
    device_5.getVariable('connected', function(data) {
  
		estado_5 = data;
   
    if ( estado_5 != false){
		$('#status_5').html("en linea");
		$('#status_5').css("color","green"); 
	
		if ($('#t5').show() != true	){
			$('#t5').show(500);
		}
		
		// Recibe Thermistorcito
	    device_5.getVariable('envia_Thermistor', function(data) {
			var valTermis = parseFloat(data.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor_5').html("desconectado");
				$('#valThermistor_5').css("color","red"); 
			}
			else{
				valTermis = valTermis.toFixed(2);
				$('#valThermistor_5').html(valTermis);
				$('#valThermistor_5').css("color","gray");
			}
		});
	
		// Recibe BMP180 temperatura
		device_5.getVariable('bmpTemp', function(data) {
			var redBMPT = data.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_5').html(redBMPT);
		});
	
		// Recibe BMP180 presion
		device_2.getVariable('bmpPres', function(data) {
			$('#valPresBMP_5').html(data.bmpPres);
		});
    }
    else{
		$('#status_5').html("fuera de linea");
		$('#status_5').css("color","red"); 
		
		if ($('#t5').hide() != true	){
			$('#t5').hide(500);
		}
		//$.ajaxq.clear(qname);
		return;
    }
		
 
    });
	}
	//setInterval(trabajoSucio_5, 5000);
	**/
	
	//Dispositivo 1
	
	function trae_info(){
		var gotData = false;
		
		var jqxhr = $.ajax({
			//url: 'http://192.168.1.112/?callback=?',
			//url: 'http://10.0.0.06/?callback=?',
			//url: 'http://192.168.1.111/?callback=?',
			//url: 'http://192.168.0.120/?callback=?',
			//url: 'http://10.0.0.15/?callback=id=1?',
			url: 'http://'+ ip_1 + '/?callback=id=1?',
			dataType: 'json',
			jsonpCallback:'variables',
			 cache: false
			})
			
			//setTimeout(updateValues,1000);
		
			// if the request was successful...
			.done(function(data) { 	
				//estado = data;
				
				//if ( estado != false){
					$('#status').html("en linea");
					//$('#status').css("color","green"); 
					document.getElementById("status").className = "label label-success";
	
					if ($('#t1').show() != true	){
						$('#t1').show(500);
					}
				//}
			
				console.log("---------- Dispositivo 1 en Linea ----------");
				console.log("Temperature BMP180:\t" + data.variables.bmpTemp);
				console.log("Presion Atm BMP180:\t" + data.variables.bmpPres);
				console.log("Thermistor:\t" + data.variables.envia_Thermistor);
				console.log("");
				console.log("Updating values...");
				
			$('#valTempBMP').html(data.variables.bmpPres);
			
			var redBMPT = data.variables.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP').html(redBMPT);
			
			$('#valPresBMP').html(data.variables.bmpPres);
			
		    valTermis = parseFloat(data.variables.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor').html("desconectado");
				$('#valThermistor').css("color","red"); 
			}
			else{
				cont++;
				var valTermis = valTermis.toFixed(2);
				$('#valThermistor').html(valTermis);
				$('#valThermistor').css("color","gray");
				//graf_D1.push([x, valTermis]);
				
				//JQPlot update charts, removing the oldest value		
				var x = (new Date()).getTime();
				//var x = cont;
				//if(tempData.length == 10) tempData.shift();
				tempData.push([x, valTermis]);
				tempChar.series[0].data = tempData;
				tempChar.resetAxesScale();
				//tempChar.axes.xaxis.min = 0;
				//tempChar.axes.xaxis.max = 500;
				tempChar.axes.xaxis.tickInterval = '300 second';
				tempChar.axes.yaxis.min = -25;
				tempChar.axes.yaxis.max = 30;
				tempChar.axes.yaxis.tickInterval = 5;
				tempChar.replot();
				//graf_D1.push(valTermis);
				
				//plot.setData([getRandomData()]);

			// Since the axes don't change, we don't need to call plot.setupGrid()

			  // plot.draw();
			}
										
				console.log("...done!");
				console.log("");				
			})
			
			// if error print it on JS console
			.fail(function() { 
				console.log( "Dispositivo 1 fuera de linea :("); 
				
				$('#status').html("fuera de linea");
				//$('#status').css("color","red"); 
				document.getElementById("status").className = "label label-default";
		
				if ($('#t1').hide() != true	){
					$('#t1').hide(500);
				}
				return;
			});
			
		/**	if(++cont > 0){
			setTimeout(trae_info,10000);
			}	**/
			
	} // final funcion trae_info
	
	//Dispositivo 2
	function trae_info_2(){
		var gotData_2 = false;
		
		var jqxhr_2 = $.ajax({
			//url: 'http://192.168.1.112/?callback=?',
			//url: 'http://10.0.0.06/?callback=?',
			//url: 'http://192.168.1.111/?callback=?',
			//url: 'http://192.168.0.120/?callback=?',
			//url: 'http://192.168.1.115/?callback=id=1?',
			url: 'http://'+ ip_2 + '/?callback=id=1?',
			dataType: 'json',
			jsonpCallback:'variables',
			 cache: false
			})
			
			//setTimeout(updateValues,1000);
		
			// if the request was successful...
			.done(function(data) { 		
				
					$('#status_2').html("en linea");
					//$('#status_2').css("color","green"); 
					document.getElementById("status_2").className = "label label-success";
	
					if ($('#t2').show() != true	){
						$('#t2').show(500);
					}
			
				console.log("---------- Dispositivo 2 en Linea ----------");
				console.log("Temperature BMP180:\t" + data.variables.bmpTemp);
				console.log("Presion Atm BMP180:\t" + data.variables.bmpPres);
				console.log("Thermistor:\t" + data.variables.envia_Thermistor);
				console.log("");
				console.log("Updating values...");
				
			//var redBMPT = data.bmpTemp;
			//redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_2').html(data.variables.bmpPres);
			
			var redBMPT = data.variables.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_2').html(redBMPT);
			
			$('#valPresBMP_2').html(data.variables.bmpPres);
			
			var valTermis = parseFloat(data.variables.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor_2').html("desconectado");
				$('#valThermistor_2').css("color","red"); 
			}
			else{
				 var valTermis = valTermis.toFixed(2);
				$('#valThermistor_2').html(valTermis);
				$('#valThermistor_2').css("color","gray");
				//JQPlot update charts, removing the oldest value		
				var x = (new Date()).getTime();
				//var x = cont;
				//if(tempData.length == 10) tempData.shift();
				tempData_2.push([x, valTermis]);
				tempChar_2.series[0].data = tempData_2;
				tempChar_2.resetAxesScale();
				//tempChar.axes.xaxis.min = 0;
				//tempChar.axes.xaxis.max = 500;
				tempChar_2.axes.xaxis.tickInterval = '300 second';
				tempChar_2.axes.yaxis.min = -25;
				tempChar_2.axes.yaxis.max = 30;
				tempChar_2.axes.yaxis.tickInterval = 5;
				tempChar_2.replot();
			}
			//$('#valThermistor_2').html(data.variables.envia_Thermistor);
	
				console.log("...done!");
				console.log("");	
			})
			
			// if error print it on JS console
			.fail(function() { 
				console.log( "Dispositivo 2 fuera de linea :("); 
				$('#status_2').html("fuera de linea");
				//$('#status_2').css("color","red");
				document.getElementById("status_2").className = "label label-default";				
		
				if ($('#t2').hide() != true	){
					$('#t2').hide(500);
				}
				return;
				});
			
		/**	if(++cont > 0){
			setTimeout(trae_info_2,10000);
			}	**/
	} // final funcion trae_info_2
	
	
	//Dispositivo 3
	function trae_info_3(){
		var gotData_2 = false;
		
		var jqxhr_3 = $.ajax({
			//url: 'http://192.168.1.112/?callback=?',
			//url: 'http://10.0.0.06/?callback=?',
			//url: 'http://192.168.1.111/?callback=?',
			//url: 'http://192.168.0.120/?callback=?',
			//url: 'http://192.168.1.115/?callback=id=1?',
			url: 'http://'+ ip_3 + '/?callback=id=1?',
			dataType: 'json',
			jsonpCallback:'variables',
			 cache: false
			})
			
			//setTimeout(updateValues,1000);
		
			// if the request was successful...
			.done(function(data) { 		
				
					$('#status_3').html("en linea");
					$('#status_3').css("color","green"); 
	
					if ($('#t3').show() != true	){
						$('#t3').show(500);
					}
			
				console.log("---------- Dispositivo 3 en Linea ----------");
				console.log("Temperature BMP180:\t" + data.variables.bmpTemp);
				console.log("Presion Atm BMP180:\t" + data.variables.bmpPres);
				console.log("Thermistor:\t" + data.variables.envia_Thermistor);
				console.log("");
				console.log("Updating values...");
				
			//var redBMPT = data.bmpTemp;
			//redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_3').html(data.variables.bmpPres);
			
			var redBMPT = data.variables.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_3').html(redBMPT);
			
			$('#valPresBMP_3').html(data.variables.bmpPres);
			
			var valTermis = parseFloat(data.variables.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor_3').html("desconectado");
				$('#valThermistor_3').css("color","red"); 
			}
			else{
				valTermis = valTermis.toFixed(2);
				$('#valThermistor_3').html(valTermis);
				$('#valThermistor_3').css("color","gray");
			}
	
				console.log("...done!");
				console.log("");	
			})
			
			// if error print it on JS console
			.fail(function() { 
				console.log( "Dispositivo 3 fuera de linea :("); 
				$('#status_3').html("fuera de linea");
				$('#status_3').css("color","red"); 
		
				if ($('#t3').hide() != true	){
					$('#t3').hide(500);
				}
				return;
				});
			
		/**	if(++cont > 0){
			setTimeout(trae_info_2,10000);
			}	**/
	} // final funcion trae_info_3
	
	
	//Dispositivo 4
	function trae_info_4(){
		var gotData_4 = false;
		
		var jqxhr_4 = $.ajax({
			//url: 'http://192.168.1.112/?callback=?',
			//url: 'http://10.0.0.06/?callback=?',
			//url: 'http://192.168.1.111/?callback=?',
			//url: 'http://192.168.0.120/?callback=?',
			//url: 'http://192.168.1.115/?callback=id=1?',
			url: 'http://'+ ip_4 + '/?callback=id=1?',
			dataType: 'json',
			jsonpCallback:'variables',
			 cache: false
			})
			
			//setTimeout(updateValues,1000);
		
			// if the request was successful...
			.done(function(data) { 		
				
					$('#status_4').html("en linea");
					$('#status_4').css("color","green"); 
	
					if ($('#t4').show() != true	){
						$('#t4').show(500);
					}
			
				console.log("---------- Dispositivo 4 en Linea ----------");
				console.log("Temperature BMP180:\t" + data.variables.bmpTemp);
				console.log("Presion Atm BMP180:\t" + data.variables.bmpPres);
				console.log("Thermistor:\t" + data.variables.envia_Thermistor);
				console.log("");
				console.log("Updating values...");
				
			//var redBMPT = data.bmpTemp;
			//redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_4').html(data.variables.bmpPres);
			
			var redBMPT = data.variables.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_4').html(redBMPT);
			
			$('#valPresBMP_4').html(data.variables.bmpPres);
			
			var valTermis = parseFloat(data.variables.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor_4').html("desconectado");
				$('#valThermistor_4').css("color","red"); 
			}
			else{
				valTermis = valTermis.toFixed(2);
				$('#valThermistor_4').html(valTermis);
				$('#valThermistor_4').css("color","gray");
			}
			//$('#valThermistor_2').html(data.variables.envia_Thermistor);
	
				console.log("...done!");
				console.log("");	
			})
			
			// if error print it on JS console
			.fail(function() { 
				console.log( "Dispositivo 4 fuera de linea :("); 
				$('#status_4').html("fuera de linea");
				$('#status_4').css("color","red"); 
		
				if ($('#t4').hide() != true	){
					$('#t4').hide(500);
				}
				return;
				});
			
		/**	if(++cont > 0){
			setTimeout(trae_info_2,10000);
			}	**/
	} // final funcion trae_info_4
	
	
	//Dispositivo 5
	function trae_info_5(){
		var gotData_5 = false;
		
		var jqxhr_5 = $.ajax({
			//url: 'http://192.168.1.112/?callback=?',
			//url: 'http://10.0.0.06/?callback=?',
			//url: 'http://192.168.1.111/?callback=?',
			//url: 'http://192.168.0.120/?callback=?',
			//url: 'http://192.168.1.115/?callback=id=1?',
			url: 'http://'+ ip_5 + '/?callback=id=1?',
			dataType: 'json',
			jsonpCallback:'variables',
			 cache: false
			})
			
			//setTimeout(updateValues,1000);
		
			// if the request was successful...
			.done(function(data) { 		
				
					$('#status_5').html("en linea");
					$('#status_5').css("color","green"); 
	
					if ($('#t5').show() != true	){
						$('#t5').show(500);
					}
			
				console.log("---------- Dispositivo 2 en Linea ----------");
				console.log("Temperature BMP180:\t" + data.variables.bmpTemp);
				console.log("Presion Atm BMP180:\t" + data.variables.bmpPres);
				console.log("Thermistor:\t" + data.variables.envia_Thermistor);
				console.log("");
				console.log("Updating values...");
				
			//var redBMPT = data.bmpTemp;
			//redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_5').html(data.variables.bmpPres);
			
			var redBMPT = data.variables.bmpTemp;
			redBMPT = redBMPT.toFixed(2);
			$('#valTempBMP_5').html(redBMPT);
			
			$('#valPresBMP_5').html(data.variables.bmpPres);
			
			var valTermis = parseFloat(data.variables.envia_Thermistor);
			if (valTermis < -64){
				$('#valThermistor_5').html("desconectado");
				$('#valThermistor_5').css("color","red"); 
			}
			else{
				valTermis = valTermis.toFixed(2);
				$('#valThermistor_5').html(valTermis);
				$('#valThermistor_5').css("color","gray");
			}
			//$('#valThermistor_2').html(data.variables.envia_Thermistor);
	
				console.log("...done!");
				console.log("");	
			})
			
			// if error print it on JS console
			.fail(function() { 
				console.log( "Dispositivo 5 fuera de linea :("); 
				$('#status_5').html("fuera de linea");
				$('#status_5').css("color","red"); 
		
				if ($('#t5').hide() != true	){
					$('#t5').hide(500);
				}
				return;
				});
			
		/**	if(++cont > 0){
			setTimeout(trae_info_2,10000);
			}	**/
	} // final funcion trae_info_5
	
	/*function grafJS() {

		var d1 = [];
				for (var i = 0; i < 14; i += 0.5) {
					d1.push([i, Math.sin(i)]);
				}
				
				/*for(var i = 0; i < 1; i++) {			
					//tempData.push([startTime, 20]);
					d2.push([startTime, 50]);
					//startTime += 10000;
				} 
				var d2 = graf_D1; 

				// A null signifies separate line segments

				var d3 = [[0, 12], [7, 12], null, [7, 2.5], [12, 2.5]];

				$.plot("#placeholder", [ d1, d2, d3 ]);
	}); */
	

		
	// Function that displays the two charts
	function showCharts() {

		tempChar =  $.jqplot('tempchartdiv', [tempData], {				
			title: 'Gráfica de temperaturas en Dispositivo 1',
			 seriesDefaults:{trendline:{show:true, type:"exp"}},
			axes: {
				xaxis: {
					labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
					renderer:$.jqplot.DateAxisRenderer,
					tickOptions: {
							formatString:'%H:%M'
					},
					tickInterval:'60 second'
				},
				yaxis: {
					min: -25,
					max: 30,
					//tickInterval: 20,
					label:'°C',
					renderer: $.jqplot.CategoryAxisRenderer,
					labelRenderer: $.jqplot.CanvasAxisLabelRenderer
					
				}
			},
			seriesDefaults: { 
					showMarker:false,
					pointLabels: { show:true } 
				}
		});
		tempChar_2 =  $.jqplot('graf_TD2', [tempData_2], {				
			title: 'Gráfica de temperaturas en Dispositivo 2',
			 seriesDefaults:{trendline:{show:true, type:"exp"}},
			axes: {
				xaxis: {
					labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
					renderer:$.jqplot.DateAxisRenderer,
					tickOptions: {
							formatString:'%H:%M'
					},
					tickInterval:'60 second'
				},
				yaxis: {
					min: -25,
					max: 30,
					//tickInterval: 20,
					label:'°C',
					renderer: $.jqplot.CategoryAxisRenderer,
					labelRenderer: $.jqplot.CanvasAxisLabelRenderer
					
				}
			},
			seriesDefaults: { 
					showMarker:false,
					pointLabels: { show:true } 
				}
		});
/**
		humChar =  $.jqplot('humchartdiv', [humData], {				
			title: 'Humidity',
			axes: {
				xaxis: {
					renderer:$.jqplot.DateAxisRenderer,
					tickOptions: {
							//formatString:'%H:%M:%S'
					},
					tickInterval: 30
				},
				yaxis: {
					min: 0,
					max: 100,
					tickInterval: 10
				}
			}
		});	
		
	
	var ctx = document.getElementById("myChart");
	var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            label: "Dispositivo 1",
            fill: false,
            lineTension: 0.1,
            backgroundColor: "rgba(75,192,192,0.4)",
            borderColor: "rgba(75,192,192,1)",
            borderCapStyle: 'butt',
            borderDash: [],
            borderDashOffset: 0.0,
            borderJoinStyle: 'miter',
            pointBorderColor: "rgba(75,192,192,1)",
            pointBackgroundColor: "#fff",
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBackgroundColor: "rgba(75,192,192,1)",
            pointHoverBorderColor: "rgba(220,220,220,1)",
            pointHoverBorderWidth: 2,
            pointRadius: 1,
            pointHitRadius: 10, 
            data: ["graf_D1"],
        }] 
    },
   
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
}); **/

	$("#resizable1").resizable({delay:20});
	$('#resizable1').bind('resize', function(event, ui) {
	   $('#tempchartdiv').height($('#resizable1').height()*0.96);
	   $('#tempchartdiv').width($('#resizable1').width()*0.96);
      // pass in resetAxes: true option to get rid of old ticks and axis properties
      // which should be recomputed based on new plot size.
      //tempChar.replot( { resetAxes: true } );
	}); 
  
	$("#resizable2").resizable({delay:20});
	$('#resizable2').bind('resize', function(event, ui) {
	   $('#graf_TD2').height($('#resizable2').height()*0.96);
	   $('#graf_TD2').width($('#resizable2').width()*0.96);
      // pass in resetAxes: true option to get rid of old ticks and axis properties
      // which should be recomputed based on new plot size.
      //tempChar.replot( { resetAxes: true } );
  });

	}
	
	/**
	var data = [],
			totalPoints = 300;

		function getRandomData() {

			if (data.length > 0)
				data = data.slice(1);

			// Do a random walk

			while (data.length < totalPoints) {

			/*	var prev = data.length > 0 ? data[data.length - 1] : 50,
					y = prev + Math.random() * 10 - 5;

				if (y < 0) {
					y = 0;
				} else if (y > 100) {
					y = 100;
				} *

				data.push(valTermis);
			}

			// Zip the generated y values with the x values

			var res = [];
			for (var i = 0; i < data.length; ++i) {
				res.push([i, data[i]])
			}

			return res;
		}

		// Set up the control widget

		var updateInterval = 30;
		$("#updateInterval").val(updateInterval).change(function () {
			var v = $(this).val();
			if (v && !isNaN(+v)) {
				updateInterval = +v;
				if (updateInterval < 1) {
					updateInterval = 1;
				} else if (updateInterval > 2000) {
					updateInterval = 2000;
				}
				$(this).val("" + updateInterval);
			}
		});

		var placeholder = $("#placeholder");
		var plot = $.plot(placeholder, [ getRandomData() ], {
			series: {
				shadowSize: 0	// Drawing is faster without shadows
			},
			yaxis: {
				min: -25,
				max: 35,
				ticks: 5
			},
			xaxis: {
				show: true,
				mode: "time",
				minTickSize: [1, "minute"],
					//min: (new Date()).getTime(),
				//	max: (new Date()).getTime(),
				
				timeformat: "%H:%M",
					twelveHourClock: true
			},
		});

		function update() {

			//plot.setData([getRandomData()]);

			// Since the axes don't change, we don't need to call plot.setupGrid()

			//plot.draw();
			setTimeout(update, updateInterval);
		}

		update();

		// Add the Flot version string to the footer

		//$("#footer").prepend("Flot " + $.plot.version + " &ndash; ");
	placeholder.resize(function () {
			$(".message").text("Placeholder is now "
				+ $(this).width() + "x" + $(this).height()
				+ " pixels");
		});

		$(".demo-container").resizable({
			maxWidth: 900,
			maxHeight: 500,
			minWidth: 360,
			minHeight: 220
		});
	    **/

});

